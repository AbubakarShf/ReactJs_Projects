import React from 'react';

function App() {
  return (
    <div>
      <button>-</button>
      <span>0</span>
      <button>+</button>
    </div>
  )
}

export default App;
