import React from 'react'

export default function RecipeIngredientEdit() {
  return (
    <>
      <input type="text" />
      <input type="text" />
      <button>&times;</button>
    </>
  )
}
