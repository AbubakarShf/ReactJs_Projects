//using selectors inside the element
// traversing the dom
