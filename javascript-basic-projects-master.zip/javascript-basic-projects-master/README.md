## You can see all projects in action here

[Projects](https://www.vanillajavascriptprojects.com/)
