export default 'LOAD_GIFS';
