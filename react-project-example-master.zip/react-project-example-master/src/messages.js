export default {
  en: {
    'hello.world': 'Hello world',
    'load.gifs': 'Load Gifs'
  },
  'pt-BR': {
    'hello.world': 'Oi mundo',
    'load.gifs': 'Carregar Gifs'
  },
  es: {
    'hello.world': 'Hola mundo',
    'load.gifs': 'Cargar Gifs'
  }
};
