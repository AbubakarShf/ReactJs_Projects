export default {
  gifs: {}
};
