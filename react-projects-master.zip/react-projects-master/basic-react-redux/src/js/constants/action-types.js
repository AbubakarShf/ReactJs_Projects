// Constants used instead of strings to prevent typo issues

export const ADD_ARTICLE = "ADD_ARTICLE";